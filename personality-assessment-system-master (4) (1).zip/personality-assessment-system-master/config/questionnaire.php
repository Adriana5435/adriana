<?php
    return [
        'person_type_details' => [
            'vijegishakhsiati' => 'Personality Attribute',
            'darmahalekar' => 'At Workplace',
            'anavinshodhli' => 'Job Titles',
            'ertebatbadigaran' => 'Interpersonal Relationships',
            'oghateferaghat' => 'Leisure Time',
            'shoaretip' => 'Personality Slogan',
            'mashaghelemonaseb' => 'Suitable Careers',
            'noghateghovat' => 'Strengths at Work',
            'noghatezaf' => 'Weaknesses at Work',
            'pishnahademovafaghiat' => 'Success Advice',
            'saier' => 'Other Descriptions',
            'modelmard' => 'Asset Allocation Model Based on Personality Type and Male Gender',
            'modelzan' => 'Asset Allocation Model Based on Personality Type and Female Gender',
        ]
    ];
